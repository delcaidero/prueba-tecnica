# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['etltools']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.5.3,<2.0.0',
 'psycopg2-binary>=2.9.5,<3.0.0',
 'sqlalchemy>=2.0.4,<3.0.0']

setup_kwargs = {
    'name': 'etltools',
    'version': '0.1.0',
    'description': 'Prueba práctica de ETL',
    'long_description': '',
    'author': 'Alby',
    'author_email': 'delcaidero@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
